package iessoterohernandez.es;

import java.math.BigDecimal;
import java.text.DecimalFormat;

public class fibonacci {
	private BigDecimal termino_inicial = BigDecimal.valueOf(0);
	 private BigDecimal termino_siguiente = BigDecimal.valueOf(1);
	 private BigDecimal termino_temp = BigDecimal.valueOf(0);

	 private int total_terminos;

	 private DecimalFormat format = new DecimalFormat("###,###");
	 
	 public fibonacci(int total_terminos) {
	  this.total_terminos = total_terminos;
	 }

	 public int getTotal_terminos() {
	  return total_terminos;
	 }

	 public void setTotal_terminos(int total_terminos) {
	  this.total_terminos = total_terminos;
	  this.termino_inicial = BigDecimal.valueOf(0);
	  this.termino_siguiente = BigDecimal.valueOf(1);
	  this.termino_temp = BigDecimal.valueOf(0);
	 }
	 
	 public void generarFibonacci() {
	  
	  int i = 0;
	  
	  for( i = 3 ; i <= total_terminos; i++) {
	   
	   termino_temp = termino_inicial.add(termino_siguiente);
	   termino_inicial = termino_siguiente;
	   termino_siguiente = termino_temp;
	  }
	  
	  System.out.println("" + (i-1) + " - " + format.format(termino_temp));  
	  System.out.println("");
	  
	 }

	
}
