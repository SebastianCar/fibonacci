package iessoterohernandez.es1;

import iessoterohernandez.es.fibonacci;

public class fibonacciMain {

	public static void main(String[] args) {
		fibonacci fib = new fibonacci(150);
		
		fib.generarFibonacci();
	}

}
